For old ARC driver (kernel version below 3.0.35), the test cases
is from FSL-UT-USB-001.txt - FSL-UT-USB-029.txt (if existed).

For new chipidea driver (kernel version above 3.10), the test cases
is from 030-xxx.txt.
